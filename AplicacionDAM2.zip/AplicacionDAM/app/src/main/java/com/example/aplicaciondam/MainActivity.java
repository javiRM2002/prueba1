package com.example.aplicaciondam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethod;
import android.view.inputmethod.InputMethodManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int contador = 21;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR);
        setContentView(R.layout.activity_main);
        TextView resultado = (TextView) findViewById(R.id.valorContador);
        resultado.setText("" + contador);
        EventoTeclado teclado = new EventoTeclado();
        EditText n_reseteo = (EditText) findViewById(R.id.valorReseteo);
        n_reseteo.setOnEditorActionListener(teclado);

    }

    class EventoTeclado implements TextView.OnEditorActionListener {
        @Override
        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            if (i == EditorInfo.IME_ACTION_DONE) {
                reseteo(null);
            }

            return false;
        }

    }

    public void sumar(View j) {
        contador = contador + 1;
        TextView resultado = (TextView) findViewById(R.id.valorContador);
        resultado.setText("" + contador);
    }

    public void restar(View c) {
        contador = contador - 1;

        if (contador < 0) {
            CheckBox checkBox = (CheckBox) findViewById(R.id.negativos);
            if (!checkBox.isChecked()) {
                contador = 0;
            }

        }
        TextView resultado = (TextView) findViewById(R.id.valorContador);

        resultado.setText("" + contador);

    }

    public void reseteo(View v) {
        contador = 0;
        TextView resultado = (TextView) findViewById(R.id.valorContador);
        resultado.setText("" + contador);


    }

    public void valorReseteo(View e) {
        EditText numero_reseteo = (EditText) findViewById(R.id.valorReseteo);
        try {
            contador = Integer.parseInt(numero_reseteo.getText().toString());
        } catch (Exception e1) {
            contador = 0;
        }
        contador = Integer.parseInt(numero_reseteo.getText().toString());
        TextView resultado = (TextView) findViewById(R.id.valorContador);
        resultado.setText("" + contador);

        InputMethodManager teclado = (InputMethodManager) getSystemService((INPUT_METHOD_SERVICE));
        teclado.hideSoftInputFromWindow(numero_reseteo.getWindowToken(), 0);
    }
    public void onPause () {
        super.onPause();
        SharedPreferences datos = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor miEditor = datos.edit();
        miEditor.putInt("cuenta", contador);
        miEditor.apply();
    }


    public void onResume () {
        super.onResume();
        SharedPreferences datos = PreferenceManager.getDefaultSharedPreferences(this);
        contador = datos.getInt("cuenta", 0);
        TextView resultado = (TextView) findViewById(R.id.valorContador);
        resultado.setText("" + contador);
    }
}