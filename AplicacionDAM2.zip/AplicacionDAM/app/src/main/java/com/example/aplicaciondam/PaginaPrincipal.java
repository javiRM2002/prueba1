package com.example.aplicaciondam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class PaginaPrincipal extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pagina_principal);
    }
    public void ejecutar_contador(View v){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);

    }
    public void ejecutar_calculadora(View x){
        Intent j = new Intent(this,Calculadora.class);
        startActivity(j);
    }
}